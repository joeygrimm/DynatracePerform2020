import requests
import json
import logging
from ruxit.api.base_plugin import RemoteBasePlugin

logger = logging.getLogger(__name__)

class SpaceXPlugin(RemoteBasePlugin):

    def initialize(self, **kwargs):
        # self.base_url = "http://localhost:5000"
        self.config = kwargs['config']
        self.base_url = self.config["url"]
        
    def query(self, **kwargs):
        ship_count = 0
        self.status_mappings = self.resolve_status_mappings(kwargs['json_config'])
        for ship_type, ships in self.load_ships().items():
            group = self.topology_builder.create_group(ship_type, ship_type)
            for ship in ships:
                ship_count = ship_count + 1
                device = group.create_device(ship['ship_id'], ship['ship_name'])
                device.add_endpoint(ship['ship_ip'])
                self.report_ship_metrics(ship, device)
        logger.info('%d ships found' % ship_count)

    def get_attribute(self, ship, attribute_name):
        if ship is None:
            return None
        if attribute_name not in ship:
            return None
        return ship[attribute_name]

    def report_attribute(self, ship, attribute_name, device, property_name):
        if ship is None:
            return
        if attribute_name is None:
            return
        if device is None:
            return
        if property_name is None:
            return
        attribute = self.get_attribute(ship, attribute_name)
        if attribute is None:
            return
        device.report_property(property_name, attribute)

    def report_absolute_metric(self, ship, attribute_name, device, metric_key):
        if ship is None:
            return
        if attribute_name is None:
            return
        if metric_key is None:
            return
        if device is None:
            return
        metric_value = self.get_attribute(ship, attribute_name)
        if metric_value is None:
            return
        device.absolute(key = metric_key, value = metric_value)

    def resolve_status_mappings(self, json_config):
        metrics = json_config['metrics']
        for metric in metrics:
            if 'statetimeseries' not in metric:
                continue
            statetimeseries = metric['statetimeseries']
            key = statetimeseries['key']
            if key != 'status':
                continue
            return metric['source']

    def map_status(self, status):
        if status is None:
            return "Unknown"
        for key, values in self.status_mappings.items():
            for value in values:
                if status == value:
                    return key
        return "Other"

    def report_ship_metrics(self, ship, device):
        status = self.map_status(self.get_attribute(ship, 'status'))
        device.state_metric("status", status)
        # logger.info('%s -> %s' % (ship['ship_name'], status))
        
        self.report_attribute(ship, 'home_port', device, 'Home Port')
        self.report_attribute(ship, 'url', device, 'URL')
        
        self.report_absolute_metric(ship, 'fuel', device, 'fuel')
        self.report_absolute_metric(ship, 'speed_kn', device, 'speed')

        thrust = ship['thrust']
        for thrust_entry in thrust:
            engine = thrust_entry['engine']
            power = thrust_entry['power']
            device.absolute(key='thrust', value=power, dimensions = { 'engine': engine })

    def load_ships(self):
        results = {}
        resp = requests.get("http://localhost:5000/v3/ships")
        # logger.info(resp.text)
        records = json.loads(resp.content)
        for ship in records:
            ship_type = ship['ship_type']
            ships_for_type = []
            if ship_type in results:
                ships_for_type = results[ship_type] 
            ships_for_type.append(ship)
            results[ship_type] = ships_for_type
        return results
